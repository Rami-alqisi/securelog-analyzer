import re
from collections import Counter
from utils import load_logs, parse_log_entry

class LogDetector:
    def __init__(self, log_file=None, log_data=None):
        """
        Initializes the detector with either a log file path or a list of log entries.
        """
        if log_file:
            self.logs = load_logs(log_file)
        elif log_data:
            self.logs = [parse_log_entry(line.strip()) for line in log_data if parse_log_entry(line.strip())]
        else:
            self.logs = []

    def detect_brute_force(self, threshold=3):
        """
        Detects brute force attacks by looking for repeated failed login attempts from the same IP.
        """
        failed_attempts = []
        for log in self.logs:
            if log['level'] == 'WARNING' and 'Failed login attempt' in log['message']:
                # Extract IP from message using regex
                ip_match = re.search(r'IP\s+([\d\.]+)', log['message'])
                if ip_match:
                    failed_attempts.append(ip_match.group(1))

        counts = Counter(failed_attempts)
        brute_force_ips = [ip for ip, count in counts.items() if count >= threshold]
        return brute_force_ips

    def detect_critical_threats(self):
        """
        Detects specific critical security threats based on keywords in CRITICAL log entries.
        """
        threats = []
        for log in self.logs:
            if log['level'] == 'CRITICAL':
                if 'Unauthorized access' in log['message']:
                    threats.append({'type': 'Unauthorized Access', 'details': log})
                elif 'SQL Injection' in log['message']:
                    threats.append({'type': 'SQL Injection', 'details': log})
                elif 'Malicious file upload' in log['message']:
                    threats.append({'type': 'Malicious File Upload', 'details': log})
                elif 'Brute-force attack' in log['message']:
                    threats.append({'type': 'Brute-Force Attack', 'details': log})
        return threats

    def get_summary_stats(self):
        """
        Returns a summary of log counts by level.
        """
        levels = [log['level'] for log in self.logs]
        return dict(Counter(levels))

if __name__ == "__main__":
    # Test with sample log file
    detector = LogDetector(log_file='logs/sample.log')
    print("Summary Stats:", detector.get_summary_stats())
    print("Brute Force IPs:", detector.detect_brute_force())
    print("Critical Threats Found:", len(detector.detect_critical_threats()))