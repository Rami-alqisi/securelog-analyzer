import re
from datetime import datetime

def parse_log_entry(log_entry):
    """
    Parses a single log entry string into a dictionary.
    Expected format: LEVEL:TIMESTAMP:MESSAGE
    """
    match = re.match(r'^(INFO|WARNING|ERROR|CRITICAL):([^:]+):(.*)$', log_entry)
    if match:
        level, timestamp_str, message = match.groups()
        try:
            timestamp = datetime.fromisoformat(timestamp_str)
        except ValueError:
            timestamp = None # Handle cases where timestamp format might be off
        return {
            'level': level,
            'timestamp': timestamp,
            'message': message.strip()
        }
    return None

def load_logs(filepath):
    """
    Loads log entries from a file and parses them.
    """
    parsed_logs = []
    with open(filepath, 'r') as f:
        for line in f:
            entry = parse_log_entry(line.strip())
            if entry:
                parsed_logs.append(entry)
    return parsed_logs

def filter_logs(logs, level=None, start_time=None, end_time=None):
    """
    Filters a list of parsed log entries based on level and time range.
    """
    filtered = logs
    if level:
        filtered = [log for log in filtered if log['level'] == level.upper()]
    if start_time:
        filtered = [log for log in filtered if log['timestamp'] and log['timestamp'] >= start_time]
    if end_time:
        filtered = [log for log in filtered if log['timestamp'] and log['timestamp'] <= end_time]
    return filtered