# SecureLog Analyzer

## Project Overview

The SecureLog Analyzer is a Python-based tool designed to parse, analyze, and visualize security-related log entries. It helps in identifying potential threats such as brute-force attacks and unauthorized access attempts through an interactive dashboard.

## Project Structure

```
securelog-analyzer/
│
├── logs/
│ └── sample.log
│
├── utils.py
├── detector.py
├── dashboard.py
├── requirements.txt
└── README.md
```

- `logs/sample.log`: Contains sample log entries for analysis.
- `utils.py`: Provides utility functions for parsing and filtering log data.
- `detector.py`: Implements logic for detecting security threats like brute-force attacks.
- `dashboard.py`: Creates an interactive web dashboard using Streamlit to visualize log data and detection results.
- `requirements.txt`: Lists all the Python dependencies required to run the project.
- `README.md`: This file, providing an overview and instructions.

## Features

- **Log Parsing**: Efficiently parses log entries from a specified file.
- **Threat Detection**: Identifies common security threats such as:
    - Brute-force attacks (repeated failed login attempts from the same IP).
    - Unauthorized access attempts.
- **Interactive Dashboard**: A user-friendly Streamlit dashboard for:
    - Viewing log summaries.
    - Visualizing log level distribution.
    - Displaying detected threats.
    - Filtering log entries by level.

## Setup and Installation

1.  **Clone the repository (or create the files manually as provided):**

    ```bash
    git clone <repository_url>
    cd securelog-analyzer
    ```

2.  **Install dependencies:**

    ```bash
    pip install -r requirements.txt
    ```

## Usage

1.  **Run the Streamlit dashboard:**

    ```bash
    streamlit run dashboard.py
    ```

2.  Open your web browser and navigate to the URL provided by Streamlit (usually `http://localhost:8501`).

## How to Extend

-   **Add new log formats**: Modify `utils.py` to include new parsing logic.
-   **Implement new detection rules**: Extend `detector.py` with more threat detection algorithms.
-   **Enhance dashboard**: Add more visualizations or filtering options in `dashboard.py`.

## License

This project is open-source and available under the MIT License. See the LICENSE file for more details. (Note: LICENSE file is not part of this project delivery, but can be added if needed.)
