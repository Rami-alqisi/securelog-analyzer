import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from detector import LogDetector
import tempfile
import os

st.set_page_config(page_title="SecureLog Analyzer Dashboard", layout="wide", initial_sidebar_state="expanded")

# Custom CSS for professional styling
st.markdown("""
    <style>
    .metric-card {
        background-color: #f0f2f6;
        padding: 20px;
        border-radius: 10px;
        margin: 10px 0;
    }
    .threat-high {
        color: #d32f2f;
        font-weight: bold;
    }
    .threat-medium {
        color: #f57c00;
        font-weight: bold;
    }
    .threat-low {
        color: #fbc02d;
        font-weight: bold;
    }
    </style>
""", unsafe_allow_html=True)

st.title("🛡️ SecureLog Analyzer Dashboard")
st.markdown("**Professional Log Analysis & Threat Detection System**")
st.markdown("---")

# Sidebar for file upload and configuration
st.sidebar.header("📁 Log File Management")

# File upload option
uploaded_file = st.sidebar.file_uploader(
    "Upload a log file (.log or .txt)",
    type=["log", "txt"],
    help="Upload your log file for analysis. Format: LEVEL:TIMESTAMP:MESSAGE"
)

# Use uploaded file or default sample
if uploaded_file is not None:
    # Save uploaded file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix=".log") as tmp_file:
        tmp_file.write(uploaded_file.getvalue())
        tmp_path = tmp_file.name
    
    detector = LogDetector(log_file=tmp_path)
    st.sidebar.success("✅ Log file loaded successfully!")
    
    # Clean up temp file
    os.unlink(tmp_path)
else:
    # Use default sample log
    detector = LogDetector(log_file='logs/sample.log')
    st.sidebar.info("📊 Using sample log file. Upload your own log file to analyze.")

# Sidebar filters
st.sidebar.header("🔍 Filters")
selected_level = st.sidebar.multiselect(
    "Select Log Level",
    options=['INFO', 'WARNING', 'ERROR', 'CRITICAL'],
    default=['INFO', 'WARNING', 'ERROR', 'CRITICAL']
)

# Main Dashboard Content
col1, col2, col3, col4 = st.columns(4)

# Summary Statistics
stats = detector.get_summary_stats()
total_logs = sum(stats.values())
critical_count = stats.get('CRITICAL', 0)
warning_count = stats.get('WARNING', 0)
error_count = stats.get('ERROR', 0)

with col1:
    st.metric("📊 Total Logs", total_logs)

with col2:
    st.metric("🚨 Critical Alerts", critical_count, delta=None if critical_count == 0 else f"+{critical_count}")

with col3:
    st.metric("⚠️ Warnings", warning_count)

with col4:
    st.metric("❌ Errors", error_count)

st.markdown("---")

# Threat Detection Section
st.subheader("🎯 Threat Detection Results")

col_threats_left, col_threats_right = st.columns(2)

with col_threats_left:
    st.markdown("### Brute-Force Attacks")
    brute_force_ips = detector.detect_brute_force(threshold=3)
    if brute_force_ips:
        st.markdown('<p class="threat-high">⚠️ THREATS DETECTED</p>', unsafe_allow_html=True)
        for ip in brute_force_ips:
            st.warning(f"🔴 Suspicious IP: {ip}")
    else:
        st.markdown('<p class="threat-low">✅ NO THREATS</p>', unsafe_allow_html=True)
        st.success("No brute-force activity detected.")

with col_threats_right:
    st.markdown("### Critical Security Threats")
    critical_threats = detector.detect_critical_threats()
    if critical_threats:
        st.markdown('<p class="threat-high">⚠️ THREATS DETECTED</p>', unsafe_allow_html=True)
        for threat in critical_threats:
            st.error(f"🔴 {threat['type']}: {threat['details']['message']}")
    else:
        st.markdown('<p class="threat-low">✅ NO THREATS</p>', unsafe_allow_html=True)
        st.success("No critical security threats detected.")

st.markdown("---")

# Visualizations
st.subheader("📈 Log Analytics & Visualizations")

col_viz_left, col_viz_right = st.columns(2)

# Log Level Distribution Pie Chart
with col_viz_left:
    st.markdown("#### Log Level Distribution")
    df_stats = pd.DataFrame(list(stats.items()), columns=['Level', 'Count'])
    if not df_stats.empty:
        fig_pie = px.pie(
            df_stats,
            values='Count',
            names='Level',
            color='Level',
            color_discrete_map={
                'INFO': '#1f77b4',
                'WARNING': '#ff7f0e',
                'ERROR': '#d62728',
                'CRITICAL': '#8b0000'
            }
        )
        fig_pie.update_layout(height=400)
        st.plotly_chart(fig_pie, use_container_width=True)

# Log Level Bar Chart
with col_viz_right:
    st.markdown("#### Log Count by Level")
    if not df_stats.empty:
        fig_bar = px.bar(
            df_stats,
            x='Level',
            y='Count',
            color='Level',
            color_discrete_map={
                'INFO': '#1f77b4',
                'WARNING': '#ff7f0e',
                'ERROR': '#d62728',
                'CRITICAL': '#8b0000'
            }
        )
        fig_bar.update_layout(height=400, showlegend=False)
        st.plotly_chart(fig_bar, use_container_width=True)

st.markdown("---")

# Log Table
st.subheader("📋 Log Entries")

df_logs = pd.DataFrame(detector.logs)
if not df_logs.empty:
    filtered_df = df_logs[df_logs['level'].isin(selected_level)].copy()
    
    # Format timestamp for display
    filtered_df['timestamp'] = filtered_df['timestamp'].astype(str)
    
    # Rename columns for better display
    display_df = filtered_df[['level', 'timestamp', 'message']].rename(columns={
        'level': 'Level',
        'timestamp': 'Timestamp',
        'message': 'Message'
    })
    
    st.dataframe(display_df, use_container_width=True, height=400)
    
    # Export option
    csv = display_df.to_csv(index=False)
    st.download_button(
        label="📥 Download Filtered Logs as CSV",
        data=csv,
        file_name="filtered_logs.csv",
        mime="text/csv"
    )
else:
    st.info("No logs available. Please upload a log file.")

st.markdown("---")
st.markdown("**SecureLog Analyzer** | Professional Log Analysis Tool | Version 2.0")